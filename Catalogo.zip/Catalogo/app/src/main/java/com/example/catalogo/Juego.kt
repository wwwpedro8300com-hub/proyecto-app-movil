package com.example.catalogo

data class Juego(
    val imagen: Int,
    val nombre: String,
    val precio: Double
)
