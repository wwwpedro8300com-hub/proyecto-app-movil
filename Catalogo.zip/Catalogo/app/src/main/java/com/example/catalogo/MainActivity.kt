package com.example.catalogo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.ViewModelProvider
import com.example.catalogo.data.CarritoRepository
import com.example.catalogo.data.database.AppDatabase
import com.example.catalogo.ui.CarritoViewModel
import com.example.catalogo.ui.CarritoViewModelFactory

class MainActivity : ComponentActivity() {
    private lateinit var vm: CarritoViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val db = AppDatabase.getDatabase(applicationContext)
        val repo = CarritoRepository(db.carritoDao())
        val factory = CarritoViewModelFactory(repo)
        vm = ViewModelProvider(this, factory).get(CarritoViewModel::class.java)

        setContent {
            Actividad8App(vm)
        }
    }
}

