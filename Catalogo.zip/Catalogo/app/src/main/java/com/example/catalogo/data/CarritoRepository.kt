package com.example.catalogo.data

import com.example.catalogo.data.database.CarritoDao
import com.example.catalogo.data.entities.CarritoEntity
import kotlinx.coroutines.flow.Flow

class CarritoRepository(private val dao: CarritoDao) {
    val carrito: Flow<List<CarritoEntity>> = dao.obtenerCarrito()

    suspend fun agregar(nombre: String, precio: Double) {
        dao.agregarProducto(CarritoEntity(nombre = nombre, precio = precio))
    }

    suspend fun eliminar(item: CarritoEntity) {
        dao.eliminarProducto(item)
    }

    suspend fun limpiar() {
        dao.limpiarCarrito()
    }
}

