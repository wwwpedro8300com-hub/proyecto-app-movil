package com.example.catalogo

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import com.example.catalogo.ui.CarritoViewModel
import androidx.compose.foundation.background

@Composable
fun PantallaCarrito(vm: CarritoViewModel) {

    val carrito = vm.items.collectAsState(initial = emptyList())
    val total = carrito.value.sumOf { it.precio }

    var compraRealizada by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF8E24AA))
            .padding(20.dp)
    ) {
        Text("Carrito de compra", color = Color.White)
        Spacer(Modifier.height(10.dp))

        if (compraRealizada) {
            Text(
                "Compra realizada con éxito",
                color = Color.Yellow,
                modifier = Modifier.padding(8.dp)
            )
            Spacer(Modifier.height(10.dp))
        }

        carrito.value.forEach { juego ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("${juego.nombre} - $${juego.precio}", color = Color.White)
                Button(onClick = { vm.remove(juego) }) { Text("Eliminar") }
            }
            Spacer(Modifier.height(8.dp))
        }

        Spacer(Modifier.height(25.dp))
        Text("Total: $${total}", color = Color.Yellow)
        Spacer(Modifier.height(25.dp))

        Button(onClick = {
            vm.clearCart()
            compraRealizada = true
        }) {
            Text("Finalizar compra")
        }
    }
}
