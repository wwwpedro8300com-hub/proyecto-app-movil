package com.example.catalogo

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import com.example.catalogo.ui.CarritoViewModel

@Composable
fun PantallaJuegos(vm: CarritoViewModel) {
    val juegos = listOf(
        Juego(R.drawable.residen, "Resident Evil 2 Remake", 899.0),
        Juego(R.drawable.mortal, "Mortal Kombat 1", 1299.0),
        Juego(R.drawable.gta, "GTA V", 499.0),
        Juego(R.drawable.fifa, "FIFA 23", 799.0),
        Juego(R.drawable.images, "Call of Duty MW", 1099.0),
        Juego(R.drawable.po, "Halo 4", 299.0)
    )

    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize().background(Color(0xFFA04394)).padding(10.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(juegos) { juego ->
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(10.dp)) {
                Image(painter = painterResource(id = juego.imagen), contentDescription = juego.nombre, modifier = Modifier.size(140.dp), contentScale = ContentScale.Crop)
                Spacer(Modifier.height(5.dp))
                Text(juego.nombre, color = Color.White)
                Text("$${juego.precio}", color = Color.Yellow)
                Button(onClick = { vm.add(juego.nombre, juego.precio) }, modifier = Modifier.padding(top = 5.dp)) {
                    Text("Agregar")
                }
            }
        }
    }
}
