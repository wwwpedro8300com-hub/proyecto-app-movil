package com.example.catalogo

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun DrawerContent(onInicio: () -> Unit, onJuegos: () -> Unit, onAcerca: () -> Unit) {
    Column(modifier = Modifier.padding(20.dp)) {
        Text("Menú", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(20.dp))
        Text("Inicio", modifier = Modifier.clickable { onInicio() }.padding(10.dp))
        Text("Juegos", modifier = Modifier.clickable { onJuegos() }.padding(10.dp))
        Text("Acerca de", modifier = Modifier.clickable { onAcerca() }.padding(10.dp))
    }
}
